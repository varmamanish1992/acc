#ifndef QTIPCSERVER_H
#define QTIPCSERVER_H

// Define AUXYCOIN-Qt message queue name
#define BITCOINURI_QUEUE_NAME "AUXYCOINURI"

void ipcScanRelay(int argc, char *argv[]);
void ipcInit(int argc, char *argv[]);

#endif // QTIPCSERVER_H
